<!-- Modal Ruoli -->
<div class="modal fade" id="addRoleModal" tabindex="-1" aria-hidden="true">
    <!-- Contenuto modale ruoli esistente -->
</div>

<!-- Modal Utenti -->
<div class="modal fade" id="userModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Gestione Utente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <!-- Form utente -->
                <form id="userForm">
                    <!-- Campi del form utente -->
                </form>
            </div>
        </div>
    </div>
</div>